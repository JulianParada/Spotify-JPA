/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Spotideezer;

import Entidades.CancionAux;
import Entidades.ListaR;
import Entidades.Pais;
import Entidades.Suscripcion;
import Entidades.Usuario;
import Facades.FacadeAgregar;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Sala BD
 */
public class MiPerfilController implements Initializable {

    @FXML
    private Label lblTipoSus;
    @FXML
    private Label lblNuevoUsu;
    @FXML
    private Label lblNombre;
    @FXML
    private Label lblNickname;
    @FXML
    private Label lblPaisSUS;
    @FXML
    private ComboBox<Pais> cmbPaisSUS;
    @FXML
    private TextField txtNickname;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApellidos;
    @FXML
    private Label lblApellidos;
    @FXML
    private Label lblMostrarMSM;
    @FXML
    private Label lblFechaInicio;
    @FXML
    private Label lblFechaRenovacion;
    @FXML
    private TextField txtFechaInicio;
    @FXML
    private TextField txtFechaRenovacion;
    @FXML
    private Button btnGuardar;
    @FXML
    private TextField txtTipoSUS;

    private final ObservableList<Pais> paisesOL = FXCollections.observableArrayList();
    public ArrayList<CancionAux> canciones = new ArrayList<>();
    private final ObservableList<CancionAux> cancionesOL = FXCollections.observableArrayList();
    private FacadeAgregar man = new FacadeAgregar();
    private Suscripcion act;
    //@FXML
    //private TableView<?> tblCancionesLike;
    @FXML
    private TableView<CancionAux> tblCancionesLike;
    @FXML
    private TableColumn<CancionAux, String> colTtulo;
    @FXML
    private TableColumn<CancionAux, String> colInterprete;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        List<Pais> paises = new ArrayList<>();
        paises = this.man.darListaDePaises();
        //System.out.println(" " + paises.size());
        this.paisesOL.setAll(paises);
        this.cmbPaisSUS.setItems(paisesOL);

        //System.out.println(ss.getNickname());
        //this.txtNickname.setText(ss.getNickname());
    }

    public void Inicializar() {
        Usuario ss = this.man.getUser();
        //System.out.println(ss.getNickname());
        this.txtNickname.setText(ss.getNickname());
        this.txtNombre.setText(ss.getNombreU());
        this.txtApellidos.setText(ss.getApellidoU());
        this.cmbPaisSUS.setValue(ss.getPaisNombrePais());

        Suscripcion sus = this.man.darSuscripcionUser();
        //System.out.println(sus.getSusTipoSus());

        if (sus.getSusTipoSus() == null) {
            this.txtTipoSUS.setText("Gratuita");
        } else if (sus.getSusTipoSus().compareTo("FAM") == 0) {
            this.txtTipoSUS.setText("Familiar");
            Date date = sus.getSusFechaInicio();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
            String strDate = dateFormat.format(date);

            this.txtFechaInicio.setText(strDate);

            Date date2 = sus.getSusFechaUltimaRenovacion();
            DateFormat dateFormat2 = new SimpleDateFormat("yyyy-mm-dd");
            String strDate2 = dateFormat.format(date2);

            this.txtFechaRenovacion.setText(strDate2);
        } else if (sus.getSusTipoSus().compareTo("IND") == 0) {
            this.txtTipoSUS.setText("Familiar");
            Date date = sus.getSusFechaInicio();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
            String strDate = dateFormat.format(date);

            this.txtFechaInicio.setText(strDate);

            Date date2 = sus.getSusFechaUltimaRenovacion();
            DateFormat dateFormat2 = new SimpleDateFormat("yyyy-mm-dd");
            String strDate2 = dateFormat.format(date2);

            this.txtFechaRenovacion.setText(strDate2);
        }

        this.canciones = (ArrayList<CancionAux>) this.man.darCancionesLikeUser();
        PropertyValueFactory<CancionAux, String> prop1 = new PropertyValueFactory<>("titulo_alabum");
        this.colTtulo.setCellValueFactory(prop1);
        PropertyValueFactory<CancionAux, String> prop3 = new PropertyValueFactory<>("nombre_artistico");
        this.colInterprete.setCellValueFactory(prop3);

        this.cancionesOL.setAll(canciones);
        this.tblCancionesLike.setItems(cancionesOL);
        System.out.println(this.canciones.size());

    }

    @FXML
    private void OnClickGuardar(ActionEvent event) {

        Usuario nn = this.man.editarInfoUsuario(this.txtNombre.getText(), this.txtApellidos.getText(), this.cmbPaisSUS.getValue().getNombrePais());
        if (nn.getApellidoU().compareTo(this.txtApellidos.getText()) == 0) {
            this.man.MostrarMensajeConfirmacion("Modificacion Realizada correctamente");

        } else {
            this.man.MostrarMensajeAdvertencia("No se Actualizo");
        }
    }

    public FacadeAgregar getMan() {
        return man;
    }

    public void setMan(FacadeAgregar man) {
        this.man = man;
    }

    public Suscripcion getAct() {
        return act;
    }

    public void setAct(Suscripcion act) {
        this.act = act;
    }

}
